import java.io.*;
import java.lang.Runnable;
import java.lang.Thread;

/**
 * Multithreaded matrix transpose program.
 *
 * Calculates the transpose of a matrix using M or N worker threads.
 * The matrix is read from a file and the resulting transpose is written to a file.
 *
 * @author Hayan Al-Machnouk
 */
public class MatrixTranspose {

    // Matrix dimensions
    private static int M;
    private static int N;

    // Matrices A and AT
    private static double[][] A;
    private static double[][] AT;

    /**
     * Main method.
     *
     * Reads the matrix from a file, calculates the transpose using worker threads,
     * and writes the result to a file.
     *
     * @param args Command line arguments (expect one argument: the file name)
     */
    public static void main(String[] args) {
        // Check that a filename was provided as a command-line argument
        if (args.length != 1) {
            System.out.println("Usage: java MatrixTranspose <filename>");
            System.exit(0);
        }
//        String[] args = {"test.txt"};
        // Read in matrix from input file
        readFile(args[0]);
        // perform the threaded transpose
        transpose();
        // Write matrix to output file
        writeFile(args[0]);
    }

    public static void readFile(String file) {
        // Read in matrix from input file
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String[] dimensions = reader.readLine().split("x");
            M = Integer.parseInt(dimensions[0]);
            N = Integer.parseInt(dimensions[1]);
            A = new double[M][N];
            AT = new double[N][M];

            // mechanism to make sure dimensions match
            int nums = -1;
            int rows = -1;
            boolean isEmpty = false;
            BufferedReader checkReader = new BufferedReader(new FileReader(file));
            while (!isEmpty) {
                String line = checkReader.readLine();
                if (line != null) {
                    rows++;
                    nums += line.split(" ").length;
                } else {
                    isEmpty = true;
                }
            }
            if ((nums != N*M) || (rows != M)) {
                throw new IncorrectDataException("Dimensions do not match matrix");
            }
            // copy matrix
            for (int i = 0; i < M; i++) {
                String[] row = reader.readLine().split(" ");
                for (int j = 0; j < N; j++) {
                    A[i][j] = Double.parseDouble(row[j]);
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Error reading input file");
            System.exit(0);
        } catch (IncorrectDataException e) {
            System.out.println("Dimensions do not match matrix");
            System.exit(0);
        }
    }

    public static void transpose() {
        System.out.println();
        System.out.printf("M = %d, N = %d\n", M, N);
        System.out.println();
        // Determine number of cores
        int numCores = Runtime.getRuntime().availableProcessors();
        // Create M or N worker threads (whichever is nearest to the number of cores you have)
        int numThreads = Math.min(M, N);
        if (numThreads > numCores) {
            numThreads = numCores;
        }
        Thread[] threads = new Thread[numThreads];
        for (int i = 0; i < numThreads; i++) {
            threads[i] = new Thread(new TransposeWorker(i, M, N, A, AT));
            System.out.printf("Thread T%d operates on column #%d of A, Writes %d values to row #%d of AT\n",
                    threads[i].getId(), i, Math.max(M, N), i);
            threads[i].start();
        }
        System.out.println();

        // Print matrix A
        System.out.println("Matrix A:");
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                System.out.print(A[i][j] + " ");
            }
            System.out.println();
        }

        // Wait for all worker threads to complete
        for (int i = 0; i < numThreads; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                System.out.println("Error waiting for worker threads to complete");
                return;
            }
        }
        System.out.println();

        // Print matrix AT
        System.out.println("Matrix AT:");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                System.out.print(AT[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void writeFile(String file) {
        // Write matrix dimensions and values to a file
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("T_"+file));
            writer.write(N + "x" + M + "\n");
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < M; j++) {
                    writer.write(AT[i][j] + " ");
                }
                writer.write("\n");
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Error writing to file");
            System.exit(0);
        }
    }

    public static double[][] getAT() {
        return AT;
    }

    public static void setA(double[][] a) {
        A = a;
    }

    public static void setM(int m) {
        M = m;
    }

    public static void setN(int n) {
        N = n;
    }

    public static void setAT(double[][] AT) {
        MatrixTranspose.AT = AT;
    }

}

/**
 * Transpose worker thread.
 *
 * Transposes a portion of the matrix and stores the result in the transpose matrix.
 */
class TransposeWorker implements Runnable {

    // Worker thread ID
    private final int id;
    // Matrix dimensions
    private final int M;
    private final int N;
    // Matrices A and AT
    private final double[][] A;
    private final double[][] AT;

    public TransposeWorker(int id, int M, int N, double[][] A, double[][] AT) {
        this.id = id;
        this.M = M;
        this.N = N;
        this.A = A;
        this.AT = AT;
    }

    public void run() {
        // Transpose matrix A and store result in AT
        for (int i = id; i < M; i += N) {
            for (int j = 0; j < N; j++) {
                AT[j][i] = A[i][j];
            }
        }
    }

    public int getId() {
        return id;
    }
}

class IncorrectDataException extends Exception {
    public IncorrectDataException(String message) {
        super(message);
    }
}


