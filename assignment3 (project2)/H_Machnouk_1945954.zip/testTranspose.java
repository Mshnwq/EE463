//import MatrixTranspose;

public class testTranspose {
    public static void main(String[] args) {
        // Test matrix transposition with different matrix sizes and number of threads
        testMatrixTranspose(4, 4);
        testMatrixTranspose(9, 4);
        testMatrixTranspose(4, 4);
        testMatrixTranspose(4, 5);
        testMatrixTranspose(4, 5);
        testMatrixTranspose(4, 5);
        testMatrixTranspose(5, 4);
        testMatrixTranspose(5, 4);
        testMatrixTranspose(5, 4);
        testMatrixTranspose(5, 5);
        testMatrixTranspose(5, 5);
        testMatrixTranspose(5, 5);
    }

    public static void testMatrixTranspose(int M, int N) {
        // Generate random matrix A
        double[][] A = new double[M][N];
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                A[i][j] = (int) (Math.random()*10);
            }
        }

        // Transpose matrix A using MatrixTranspose class
        MatrixTranspose.setM(M);
        MatrixTranspose.setN(N);
        MatrixTranspose.setA(A);
        MatrixTranspose.setAT(new double[N][M]);
        MatrixTranspose.transpose();

        // Transpose matrix A manually
        double[][] AT = new double[N][M];
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                AT[j][i] = A[i][j];
            }
        }

        // Compare matrices AT and MatrixTranspose.AT
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                if (AT[i][j] != MatrixTranspose.getAT()[i][j]) {
                    System.out.println("Error: matrices do not match");
                    return;
                }
            }
        }
        System.out.println();
        System.out.println("Success: matrices match");
        System.out.println();
    }

}
